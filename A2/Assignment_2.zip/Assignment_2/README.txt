Joshua Andrews
42144112
m1e8

For creative part:

Glowing ball
-Create new shader that will become bigger and glow when “b” is pressed.
-Move hands to make it look like armi is controlling the ball